(function () {
    let xmlData = {                                                                                 // данные для xml
        company: [],                                                                                // инф о компании
        categories: [],                                                                             // категории
        elementIds: [],                                                                             // категории
        nameGeneratedPages: [],                                                                     // имена файлов генераторов страниц для парсинга
        products: [],
    };

    const infoinformationField = document.querySelector('#information');                            // информационное поле
    const pageLayout = document.querySelector('#pageLayout');                                       // iframe в который будет генерироваться странирца для сканирования
    const btnStart = document.querySelector('#btnStart');                                           // кнопка запуска
    const btnDownload = document.querySelector('.btnDownload');                                     // кнопка скаччивания

    // ! --

    btnStart.addEventListener('click', clickStart);                                                 // нажали на кн запуска

    // ! --

    function makeDataRequest(dataType, propertyName) {                                              // TODO - выполнить запрос данных к серверу
        let request = new XMLHttpRequest();                                                         // создаем экземпляр класса XMLHttpRequest 
        request.onreadystatechange = () => {                                                        // когда запрос завершен и ответ готов
            if (request.readyState === 4) {
                xmlData[propertyName] = request.response;                                           // записать полученные данные
                displayAction(`получено (${propertyName})`);                                        // вывод действия
            }
        }
        request.open('POST', 'connector.php');                                                      // указываем параметры соединения
        request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');              // формируем заголовок
        request.responseType = 'json';                                                              // получаем json
        request.send(dataType);                                                                     // отправляем запрос          
    }

    function displayAction(text) {                                                                  // TODO - отобразить выполняемое действие
        let content = infoinformationField.innerHTML;                                               // получим текущую информацию
        infoinformationField.innerHTML = `${content} <p>${text}</p>`;                               // добавим новую и отобразим
        infoinformationField.scrollTo(0, infoinformationField.scrollHeight);                        // прокрутка
    }

    function scanPages() {                                                                          // TODO - выполнить сканирование страниц и сбор данных
        let count = xmlData.nameGeneratedPages.length;                                              // кол-во страниц для обхода
        let i = 0;                                                                                  // счетчик страниц
        xmlData.products = [];                                                                      // очищаем массив (для повторных запусков)

        displayAction(`Запуск парсинга. Страниц для сканирования: ${count}`);

        parserPage();                                                                               // запустим парсинг страницы

        function parserPage() {                                                                     // TODO - выполнить парсинг страницы
            let name = xmlData.nameGeneratedPages[i];                                               // получим имя файла-генератора страницы

            displayAction(`генерируем страницу - ${name}`);

            pageLayout.src = `./temp/${name}.php`;                                                  // добавляем в iframe ссылку на файл генератор страницы

            pageLayout.onload = function () {                                                                           // когда iframe загружен
                sleep(6000);
                displayAction(`сканируем страницу - ${name}`);

                let iframeDoc = pageLayout.contentWindow.document;                                                      // получаем содержимое iframe       

                let productData = {                                                                                     // получим данные о товаре
                    id: iframeDoc.querySelector(`.${xmlData.elementIds.id}`).textContent,                               // id
                    url: iframeDoc.querySelector(`.${xmlData.elementIds.url}`).textContent,                             // ссылка
                    price: iframeDoc.querySelector(`.${xmlData.elementIds.price}`).textContent,                         // цена
                    categoryId: iframeDoc.querySelector(`.${xmlData.elementIds.categoryId}`).textContent,               // id родительской категории
                    model: iframeDoc.querySelector(`.${xmlData.elementIds.model}`).textContent,                         // название
                    description: iframeDoc.querySelector(`.${xmlData.elementIds.description}`).textContent,             // описание
                    description_pr: iframeDoc.querySelector(`.${xmlData.elementIds.description_pr}`).textContent,       // большое описание        
                    picture: getUrl(iframeDoc.querySelector(`.${xmlData.elementIds.picture}`).querySelectorAll('img'))  // ссылки на изображения
                }

                function getUrl(elements) {                                                                             // TODO - получим массив ссылок из элементов
                    let images = Array.from(elements);
                    let url = images.map((image) => { return image.src; });
                    return url;                                                                                         // и вернем их обратно в объект
                }

                displayAction(`добавляем данные о странице ${name} в массив`);
                xmlData.products.push(productData);                                                                     // добавляем данные о странице                 

                if (i < count - 1) { i++; parserPage(); }                                                                   // если не последний элемент - запрускаем дальше
                else {
                    displayAction(`все страницы просканированны`);
                    createXML();                                                                                        // создаем xml
                }
            }
        }
    }

    function createXML() {                                                                                        // TODO - создать xml
        displayAction(`создаем xml файл`);

        let date = new Date();
        let xmlDate = date.toISOString().split('.')[0];

        console.log(xmlDate);

        let category = '';
        let offer = '';

        xmlData.categories.forEach((item) => {                                                                    // генерация содержимого блока с категориями
            if (item[1] == '') { category += `<category id="${item[0]}">${item[2]}</category>\n`; }               // для корневого раздела
            else { category += `<category id="${item[0]}" parentId="${item[1]}">${item[2]}</category>\n`; }       // для дочерних разделов
        });

        console.log(xmlData.products);

        xmlData.products.forEach((product) => {                                                                   // генерация содержимого блока с товарами
            let picture = '';                                                                                     // изображения
            product.picture.forEach((pic) => { picture += `<picture>${pic}</picture>\n`; });                      // генерация списка изображений для товара

            // генерация описания
            let des_1 = product.description.replace(/[^\w\sА-Яа-яЁё\.\,\+\-\:\;\?\!\\\/]/gi, '');
            let des_2 = product.description_pr.replace(/[^\w\sА-Яа-яЁё\.\,\+\-\:\;\?\!\\\/]/gi, '');

            let des_all = des_1 + des_2;
            let randId = getRandomArbitrary(0, 999);                                                              // случайное число для подстановки в ID товара

            function getRandomArbitrary(min, max) {
                return Math.floor(Math.random() * (max - min) + min);
            }

            let price = product.price.replace(/[^0-9\.]/g, "");                                                     // убираем лишние символы, оставляем только цифрв и точку

            if ((price === '1.0') || (price == '') || (price === 'Предзаказ')) {                                    // если цена 1.0 или пустая - не добавлем товар в xml
                displayAction(`${product.model} - не добавлен (цена: ${price})`);
                console.log(product.url);
                console.log(price);
                console.log('---------');

                return;
            }

            offer += `<offer type="vendor.model" available="true" id="${product.id}${randId}" >
                <url>${product.url}</url>
                <price>${price}</price>
                <currencyId>RUB</currencyId>
                <categoryId>${product.categoryId}</categoryId> 
                ${picture}                      
                <store>false</store>
                <pickup>true</pickup>
                <delivery>true</delivery>
                <vendor>PST</vendor>
                <model>${product.model}</model>
                <description>${des_all}</description> 
            </offer>\n`;
        });

        let content = `<?xml version="1.0" encoding="utf-8"?>
        <!DOCTYPE yml_catalog SYSTEM "shops.dtd">
        <yml_catalog date="${xmlDate}">
        <shop>
                <name>${xmlData.company['company']}</name>
                <company>${xmlData.company['company']}</company>
                <url>${xmlData.company['url']}</url>
                <platform>${xmlData.company['platform']}</platform>
                <currencies>            
                    <currency id="RUB" rate="1.0"  />            
                </currencies>
                <categories>
                    ${category}
                </categories>        
                <offers>
                    ${offer} 
                </offers>
                <promos> </promos>
            </shop>
        </yml_catalog>                         
        `;


        let request = new XMLHttpRequest();                                                         // создаем экземпляр класса XMLHttpRequest 
        request.onreadystatechange = () => {                                                        // когда запрос завершен и ответ готов
            if (request.readyState === 4) {
                displayAction(`${request.response}`);                                               // получим ответ
                btnDownload.style.display = 'flex';
            }
        }
        request.open('POST', 'generator.php');                                                      // указываем параметры соединения
        request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');              // формируем заголовок
        request.responseType = 'json';                                                              // получаем json
        request.send(`team=${content}`);                                                            // отправляем содержимое файла        
    }

    function clickStart() {                                                                         // TODO - нажали кн Старт
        displayAction('запрос данных о компании');
        makeDataRequest('dataType=companyInformation', 'company');                                  // получить данные о компании

        displayAction('запрос данных о категориях');
        makeDataRequest('dataType=categories', 'categories');                                       // получить данные по сканируемым категориям

        displayAction('получение идентификаторов элементов для сканирования');
        makeDataRequest('dataType=elementIds', 'elementIds');                                       // получить идентификаторы элементов для сканирования

        displayAction('создания файлов для дальнейшей генерации страниц');
        makeDataRequest('dataType=scannedPages', 'nameGeneratedPages');                             // получить ссылки на сгенерируемые страницы (для парсинга)

        setTimeout(scanPages, 3000);                                                                // запустить генерацию и сканирование страниц
    }

    function sleep(milliseconds) {                                                                  // задержка выполнения
        const date = Date.now();
        let currentDate = null;
        do { currentDate = Date.now(); } while (currentDate - date < milliseconds);
    }
})();
