<?php

$team = $_REQUEST['team'];                                  // получаем содержимое файла

if ($team) {
    $file = "./xml/fid.xml";                                    // путь и имя xml
    file_put_contents($file, $team);
    echo json_encode('файл создан', true);
}
