<?php
error_reporting(E_ALL);                         // вывод всех ошибок
?>

<!DOCTYPE html>
<html class="mypage" lang="ru">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Генератор xml - Общее</title>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
    <iframe id="pageLayout" src="" width="100%" height="300px"></iframe>

    <h1>Генератор xml - Общее</h1>

    <div id='information'>
        <p> ... </p>
    </div>

    <button id='btnStart'>Старт</button>
    <a class="btnDownload" href="/xml/fid.xml" target="_blank">Скачать</a>

    <script src="script.js?6"></script>
</body>

</html>