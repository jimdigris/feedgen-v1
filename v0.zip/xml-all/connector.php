<?php
require_once 'config.php';                                              // подключить конфиг с данными

$dataType = $_REQUEST['dataType'];                                      // получить тип запрашиваемых данных

// ! --

switch ($dataType) {                                                    // вернуть данные, в зависимости от запрашиваемого типа
    case 'companyInformation':
        echo json_encode($companyInformation, true);                    // передать данные о компании
        break;
    case 'categories':
        echo json_encode($categories, true);                            // передать данные о каталогах
        break;
    case 'elementIds':
        echo json_encode($elementIds, true);                            // передать данные о каталогах
        break;
    case 'scannedPages':
        $nameGeneratedPages = exeFileCreation($scannedPages);           // получить имена на файлы-генераторы страниц
        echo json_encode($nameGeneratedPages, true);                    // передать имена
        break;
}

// ! --

function exeFileCreation($scannedPages)                                                     // TODO - создать файлы-генераторы для сканируемых страниц и вернуть их имена
{
    $namePages = [];                                                                        // список имен файлов генераторов

    foreach ($scannedPages as $key => $value) {                                             // перебор ссылок, необходимых для парсинга
        $content = "<?php \$html = file_get_contents('$value', true); echo \$html;";        // формирование содержимого файла генератора будущей страницы
        $file = "./temp/$key.php";                                                          // файл для записи
        file_put_contents($file, $content);                                                 // создать файл-генератор
        array_push($namePages, $key);                                                       // добавим имя созданного файла-генератора
    }
    return $namePages;                                                                      // вернем список имен файлов генераторов
}
