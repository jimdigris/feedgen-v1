<?php
require_once 'functions.php';                                                                       // подключить файл с функциями

$action = $_REQUEST['action'];                                                                      // получить совершаемое действие

switch ($action) {                                                                                  // обработать запрос
    case 'create_temp_folder':                                                                      // создать временную папку
        $parent = $_REQUEST['parent'];                                                              // имя (путь) родительской папки
        $name = $_REQUEST['name'];                                                                  // имя временной папки
        create_temp_folder($parent, $name);                                                         // запустить создание
        break;
    case 'create_file_generator':                                                                   // создать файл генератор
        $parent = $_REQUEST['parent'];                                                              // имя (путь) родительской папки
        $name = $_REQUEST['name'];                                                                  // имя файла генератора
        $id = $_REQUEST['id'];                                                                      // offer_id
        $link = $_REQUEST['link'];                                                                  // ссылка для содержимого файла генератора
        create_file_generator($parent, $name, $id, $link);                                          // запустить создание
        break;
    case 'create_xml_file':                                                                         // создать xml файл     
        $parent = $_REQUEST['parent'];                                                              // имя (путь) родительской папки
        $name = $_REQUEST['name'];                                                                  // имя файла генератора// имя временной папки
        $content = $_REQUEST['content'];                                                            // содержимое файла
        create_xml_file($parent, $name, $content);                                                  // запустить создание
        break;
    case 'clear_temp_folder':                                                                       // очистить временную папку                                                               // имя временной папки
        $parent = $_REQUEST['parent'];                                                              // имя (путь) родительской папки
        $name = $_REQUEST['name'];                                                                  // имя временной папки
        $dir = "$parent/$name/";
        clear_temp_folder($dir);                                                                    // запустить очищение
        break;
}
