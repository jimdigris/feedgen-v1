'use strict';

const CONFIG = {                                                                                    // ! конфигурационные данные
    SETTINGS: {                                                                                     // базовые настройки
        FOLDER_TEMPL_DIR: '../temp',                                                                // папка для временных папок
        TIME_CREATE_FOLDER_TEMPL: 2000,                                                             // время ожидания ответа после создания временной папки
        PHP_FILE: './scripts/brain.php',                                                            // php скрипт на стороне сервера
        IFRAME_LOAD_TIME: 3000,                                                                     // время прогрузки содержимого iframe
        MAX_IFRAME_LOAD_TIME: 10000,                                                                // увеличенное время прогрузки содержимого iframe
        MAX_NUMBER_PAGE_SCANS: 2,                                                                   // максималльное кол-во повторных проходов сканирования
        ITERATE_OVER_ELEMENTS_TIME: 1000,                                                           // интервал для проверки получения данных для каждого оффера (создание файла-генератора, добавление в iframe, считываение)
        OFFER_COMPLETION_STATUS_TIME: 1000,                                                         // интервал проверки статуса заполнения всех офферов данными
        CREATE_XML_STATUS_TIME: 2000,                                                               // интервал проверки статуса создания xml файла
    },
    CLASSES: {                                                                                      // ! классы для поиска элементов на сгенерируемой странице для <offer></offer>
        ID: 'xml-id',
        URL: 'xml-url',
        PRICE: 'xml-price',
        CATEGORY_ID: 'xml-categoryId',
        PICTURE: 'xml-picture',
        MODEL: 'xml-model',
        DESCRIPTION_MINI: 'xml-description',
        DESCRIPTION_PRODUCT: 'product-description',
    },
    ELEMENTS: {                                                                                     // ! элементы страницы интерфейса
        IFRAME: document.querySelector('#generator'),                                               // iframe для отображения генерируемых страниц
        LOGS: document.querySelector('#logs'),                                                      // поле для вывода сообщений
        SCAN_OPTION: document.querySelector('#scan_option').querySelectorAll('input'),              // переключатели - выбор сканируемых страниц
        START: document.querySelector('#btn_start'),                                                // кнопка запуска
        DOWNLOAD: document.querySelector('#btn_download'),                                          // кнопка скачивания готового xml файла
    },
};

const XML_DATA = {                                                                                  // ! данные для формирования xml файла
    INFO: {                                                                                         // основные данные
        NAME: 'ООО Курс',                                                                           // <name></name>
        COMPANY: 'ООО Курс',                                                                        // <company></company>
        LINK_SITE: 'https://kurs-peskostrui.ru',                                                    // <url></url>
        PLATFORM: 'InSales',                                                                        // <platform></platform>
    },
    CATIGORY: [                                                                                     // <category></category>
        ['20177898', '', 'Каталог'],
        ['21070848', '21070783', 'Сопла для пескоструйного аппарата'],
        ['21104808', '21070783', 'Рукава для пескоструйного оборудования'],
        ['21104809', '21070783', 'Соединения'],
        ['21424153', '21070783', 'Спецодежда и СИЗ для пескоструйных работ'],
        ['21647453', '21070783', 'Затворы, дозаторы'],
        ['21647521', '21070783', 'Дистанционное управление аппаратом'],
        ['21758365', '21070783', 'Перчатки для пескоструйной камеры'],
        ['21861263', '21070783', 'Фильтры'],
        ['21864659', '21070783', 'Пистолет инжекторный пескоструйный'],
        ['21928394', '20177898', 'Пескоструйный комплект'],
        ['20749683', '20177898', 'Пескоструйные аппараты'],
        ['20823424', '20177898', 'Пескоструйные камеры'],
        ['20843633', '20177898', 'Промышленные винтовые компрессоры'],
        ['22078687', '20177898', 'Обитаемая дробеструйная камера'],
        ['23689244', '20177898', 'Воздушные ресиверы и осушители'],
        ['21070783', '20177898', 'Комплектующие'],
        ['20824773', '20177898', 'Системы сбора и рекуперации абразива'],
        ['21148057', '20177898', 'Очистка воздуха'],
        ['21150864', '20177898', 'Строительное оборудование']
    ],
    PAGES: {                                                                                        // страницы для сканирования
        APPARAT: [
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/peskostruynyy-apparat-pst-25-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/peskostruynyy-apparat-pst-75-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/peskostruynyy-apparat-pst-100-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/peskostruynyy-apparat-pst-160-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/peskostruynyy-apparat-pst-200-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/peskostruynyy-apparat-pst-250-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/peskostruynyy-apparat-pst-premium-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/peskostruynyy-apparat-pst-im-30-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/bespylevoy-peskostruynyy-apparat-ps-20-df',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/uzel-universalnyy-v-sbore-du-32-dlya-peskostruynogo-apparata-pst',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/sito-dlya-peskostruynogo-apparata-pst',
            'https://kurs-peskostrui.ru/collection/peskostruynye-apparaty/product/kryshka-dlya-peskostruynogo-apparata-pst'
        ],
        CAMERA: [
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/kamera-abrazivostruynaya-napornogo-i-inzhektornnogo-tipa-pst-kso-80-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/kamera-abrazivostruynaya-napornogo-i-inzhektornnogo-tipa-pst-kso-110-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/peskostrujnaya-kamera-PST-KSO-115-inzhektornogo-i-napornogo-tipa-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/kamera-abrazivostruynaya-napornogo-i-inzhektornnogo-tipa-pst-kso-130-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/peskostrujnaya-kamera-PST-KSO-135-inzhektornogo-i-napornogo-tipa-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/peskostrujnaya-kamera-PST-KSO-150-inzhektornogo-i-napornogo-tipa-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/peskostruynaya-kamera-s-barabanom-pst-kso-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/peskostruynaya-kamera-dlya-stekla-pst-kso-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/sistema-filtracii-rekuperacii-FVR-dlya-kamer-KSO-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/filtr-samoochischayuschiysya-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/peskostruynaya-kamera-nowag',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/filtro-ventilyatsionnaya-ustanovka-nowag',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/perchatki-kamernye-neoprenovye-s-hlopkovoy-podkladkoy-dlya-kso',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/perchatki-kamernye-dlya-kso-rezinovye-tip-2',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/perchatki-kamernye-dlya-kso-rezinovye-tip-2-azonostoykie',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/filtruyushchij-element-dlya-sf-kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/povorotnyy-stol-dlya-kso-pst',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/vydvizhnoy-povorotnyy-stol-dlya-kso-pst',
            'https://kurs-peskostrui.ru/collection/peskostruynye-kamery/product/kamera-abrazivostruynaya-pst-kso-60-Kurs'
        ],
        KOMPLEKT: [
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/komplekt-na-baze-peskostruynogo-apparata-im-30-startup',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/komplekt-na-baze-peskostruynogo-apparat-pst-25',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/komplekt-na-baze-peskostruynogo-apparat-pst-75',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/komplekt-na-baze-peskostruynogo-apparat-pst-160',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/komplekt-na-baze-peskostruynogo-apparat-pst-200',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/komplekt-na-baze-peskostruynogo-apparat-pst-250',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/komplekt-peskostruynogo-apparata-pst-premium-2',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/komplekt-zaschity-operatora',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/peskostruynyy-apparat-pst-25-kompressor',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/peskostruynyy-apparat-pst-75-kompressor',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/peskostruynyy-apparat-pst-100-kompressor',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/peskostruynyy-apparat-pst-160-kompressor',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/peskostruynyy-apparat-pst-200-kompressor',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/peskostruynyy-apparat-pst-250-kompressor',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/peskostruynyy-rukav-v-sbore',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/kombinezon-peskostruyschika-s-perchatkami-Kurs',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/peskostruynaya-kamera-kso-80-kompressor',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/peskostruynaya-kamera-kso-110-kompressor',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/komplekt-na-baze-peskostruynogo-apparat-pst-100',
            'https://kurs-peskostrui.ru/collection/peskostruynyy-komplekt/product/komplekt-startup-kompressor'
        ],
        KOMPRESSOR: [
            'https://kurs-peskostrui.ru/collection/kompressornoe-oborudovanie/product/vintovoy-kompressor-CrossAir-Dali-Kurs?variant_id=550413435',
            'https://kurs-peskostrui.ru/collection/kompressornoe-oborudovanie/product/vintovoy-kompressor-CrossAir-Dali-Kurs?variant_id=509620794',
            'https://kurs-peskostrui.ru/collection/kompressornoe-oborudovanie/product/vintovoy-kompressor-CrossAir-Dali-Kurs?variant_id=509620806',
            'https://kurs-peskostrui.ru/collection/kompressornoe-oborudovanie/product/vintovoy-kompressor-CrossAir-Dali-Kurs?variant_id=509620816',
            'https://kurs-peskostrui.ru/collection/kompressornoe-oborudovanie/product/vintovoy-kompressor-CrossAir-Dali-Kurs?variant_id=509620824',
            'https://kurs-peskostrui.ru/collection/kompressornoe-oborudovanie/product/vintovoy-kompressor-CrossAir-Dali-Kurs?variant_id=509620833',
            'https://kurs-peskostrui.ru/collection/kompressornoe-oborudovanie/product/vintovoy-kompressor-CrossAir-Dali-Kurs?variant_id=509620840',
        ],
        OTHER: [
            'https://kurs-peskostrui.ru/collection/obitaemye-kamery/product/kamera-abrazivostruynoy-ochistki-serii-kdo',
            'https://kurs-peskostrui.ru/collection/obitaemye-kamery/product/peskostruynyy-apparat-pst-premium-Kurs',
            'https://kurs-peskostrui.ru/collection/obitaemye-kamery/product/sistema-sbora-i-rekuperatsii-abraziva-sov-pst-Kurs',
            'https://kurs-peskostrui.ru/collection/obitaemye-kamery/product/ciklon-pyleulavlivatel-dlya-sov-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/obitaemye-kamery/product/filtr-samoochischayuschiysya-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/resivery-i-osushiteli/product/resiver-vozdushnyy-gorizontalnyj-rg-vertikalnyj-rv-Kurs',
            'https://kurs-peskostrui.ru/collection/resivery-i-osushiteli/product/resiver-vozdushnyy-remeza-kurs',
            'https://kurs-peskostrui.ru/collection/resivery-i-osushiteli/product/klavisha-distantsionnogo-upravleniya-k-kpdu-pst',
            'https://kurs-peskostrui.ru/collection/resivery-i-osushiteli/product/magistralnyy-filtr-crossair',
            'https://kurs-peskostrui.ru/collection/resivery-i-osushiteli/product/resiver-vozdushnyy-pst-s-ploschadkoy',
            'https://kurs-peskostrui.ru/collection/sbor-i-rekuperatsiya-abraziva/product/sistema-sbora-i-rekuperatsii-abraziva-sov-pst-Kurs',
            'https://kurs-peskostrui.ru/collection/sbor-i-rekuperatsiya-abraziva/product/sistema-filtracii-rekuperacii-FVR-dlya-kamer-KSO-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/sbor-i-rekuperatsiya-abraziva/product/ciklon-pyleulavlivatel-dlya-sov-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/sbor-i-rekuperatsiya-abraziva/product/filtr-samoochischayuschiysya-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/sbor-i-rekuperatsiya-abraziva/product/podstavka-pod-rekuperator-k-sisteme-pst-sov-Kurs',
            'https://kurs-peskostrui.ru/collection/sbor-i-rekuperatsiya-abraziva/product/bunker-nakopitelnyy-dlya-sov-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/sbor-i-rekuperatsiya-abraziva/product/bunker-priemnyy-dlya-sistemy-pst-sov-4-msov-42-m',
            'https://kurs-peskostrui.ru/collection/ochistka-vozduha/product/filtr-samoochischayuschiysya-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/ochistka-vozduha/product/filtro-ventilyatsionnaya-ustanovka-nowag',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/rastvorosmesitel-tsiklichnyy-rn-150',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/rastvorosmesitel-tsiklichnyy-rn-300',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/rastvorosmesitel-tsiklichnyy-rn-400',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/tara-dlya-rastvora-betona-tr-Kurs',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/badya-dlya-betona-bn-s-lotkom-Kurs',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/tara-dlya-rastvora-samoraskryvayuschayasya-bmch',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/zatvor-dlya-bn-kurs',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/komplekt-lopastey-v-sbore-dlya-rastvorosmesitelya-rn',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/lopatka-rezinovaya-dlya-rastvorosmesitelya-rn',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/voronka-k-bn',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/lotok-k-bn',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/vilochnyy-zahvat-lestnichnogo-marsha-zlm',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/trubogib-ruchnoy-tr-1',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/zahvat-kleschi-dlya-dorozhnogo-bordyura-zbk-1',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/vynosnaya-ploschadka-vp-12',
            'https://kurs-peskostrui.ru/collection/stroitelnoe-oborudovanie/product/stanok-dlya-gibki-armatury-arg-1',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/filtr-vlagomaslootdelitel-s-regulyatorom',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/soplo-peskostrujnoe-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/soploderzhatel-NHP-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/rukav-peskostrujnyj-Protoflex-Sand-Blasting-Hose-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/krabovoe-soedinenie-CQP-CQT-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/komplekt-zaschity-operatora',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/shlem-peskostrujshchika-Vektor-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/soplo-peskostrujnoe-vstavka-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/soplo-strujnoe-dlya-inzhektornogo-pistoleta-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/forsunka-dlya-inzhektornogo-pistoleta-PST',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/rukav-napornyy-vnd-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/rukav-kislorodnyy-vnd-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/rukav-napornyy-sdvoennyy-twin-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/krabovoe-soedinenie-cft-1-14-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/amerikanka-gayka-shtutser-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/uplotnitelnaya-trubka-v-zatvor-universalnyj-PST-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/uplotnitelnoe-koltso-dlya-gribka-pst-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/camlock-kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/filtr-k-maske-peskostruyschika-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/filtr-dlya-dyhaniya-operatora-fd-1-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/kragi-peskostruyschika-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/naruzhnoe-steklo-dlya-shlema-peskostruyschika-vektor-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/plenka-zaschitnaya-dlya-maski-peskostruyschika-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/maska-peskostruyschika-bez-filtra-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/naruzhnaya-setka-dlya-shlema-peskostruyschika-vektor-up-5-sht-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/plenka-dlya-shlema-vektor-up-50-sht-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/maska-peskostruyschika-s-filtrom-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/kombinezon-peskostruyschika-s-perchatkami-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/kombinezon-peskostruyschika-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/smotrovaya-ramka-dlya-shlema-peskostruyschika-vektor-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/pelerina-dlya-shlema-peskostruyschika-vektor-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/zastezhka-dlya-shlema-peskostruyschika-vektor-Kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/gribok-s-koltsom-pst-kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/zatvor-peschanyy-shibernogo-tipa-du-25-dlya-peskostruynogo-apparata-pst-kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/uzel-universalnyy-v-sbore-du-25-dlya-peskostruynogo-apparata-pst-kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/troynik-dlya-zatvora-pst-kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/remkomplekt-dlya-zatvora-premium-kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/shlang-naporno-vsasyvayuschiy-vnd-63-mm-10-pm',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/perchatki-kamernye-neoprenovye-s-hlopkovoy-podkladkoy-dlya-kso',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/perchatki-kamernye-dlya-kso-rezinovye-tip-2',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/perchatki-kamernye-dlya-kso-rezinovye-tip-2-azonostoykie',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/soplo-struynoe-dlya-inzhektornogo-pistoleta-nowag',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/soplo-vozdushnoe-dlya-inzhektornogo-pistoleta-nowag',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/kartridzh-smennyy-k-filtru-dlya-dyhaniya-operatora-fd-1',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/filtr-patron-dlya-vlagomaslootdelitelya',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/pistolet-inzhektornyj-dlya-apparatov-kamer-kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/filtruyushchij-element-dlya-sf-kurs',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/shtutser-yolochka',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/peskostruynyy-rukav-v-sbore',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/regulyator-dlya-shlema-peskostruyschika-vektor',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/poyasnoy-remen-k-shlemu-vektor',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/uzel-podklyucheniya-dlya-kompressora-crossair-borey',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/uzel-universalnyy-v-sbore-du-32-dlya-peskostruynogo-apparata-pst',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/perehodnik',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/elektromagnitnyy-klapan-dlya-ksosovsf',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/mufta-rezbovaya',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/amortizator-dveri-dlya-kso-110130',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/kombinezon-peskostruyschika-vektor',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/kombinezon-peskostruyschika-vektor-prof-s-perchatkami',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/filtr-dlya-dyhaniya-operatora-fp',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/kartridzh-smennyy-k-filtru-dlya-dyhaniya-operatora-fp',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/povorotnyy-stol-dlya-kso-pst',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/vydvizhnoy-povorotnyy-stol-dlya-kso-pst',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/soedinenie-stalnoe-kulachkovoe-kig',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/soedinenie-stalnoe-kulachkovoe-kag',
            'https://kurs-peskostrui.ru/collection/komplektuyushchie/product/stseplenie-krabovoe-skg'
        ],
    },
};

let data = {                                                                                        // ! данные для работы скриптов
    scan_option: '',                                                                                // выбор сканируемых страниц
    scan_links: [],                                                                                 // список ссылок, сканируемых страниц
    temp_folder_name: '',                                                                           // имя временной папки
    temp_folder_status: '',                                                                         // статус временной папки
    xml_create_status: false,                                                                       // статус xml файла
    offers: [],                                                                                     // xml <offer></offer>
    iterate_over_elements: false,                                                                   // результат создания файла-генератора (при наполнении данными)
    number_page_scans: 0,                                                                           // кол-во повторных сканирований сгенерированной страницы
    offer_completion_status: false,                                                                 // статус заполнения всех офферов данными
    link_xml_file: '',                                                                              // ссылка на xml файл
};