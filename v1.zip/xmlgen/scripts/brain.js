'use strict';

class Offer {                                                                                       // xml <offer></offer>
    xml_data = {
        id: null,
        url: null,
        price: null,
        category_id: null,
        picture: null,
        model: null,
        description_mini: null,
        description_product: null,
        description_full: null,
    };

    file_generator = null;                                                                          // файл-генератор

    constructor(offer_id, link_page) {
        this.offer_id = offer_id;                                                                   // идентификатор оффера
        this.link_page = link_page;                                                                 // ссылка на сканируемую страницу
    }
}

CONFIG.ELEMENTS.START.addEventListener('click', click_start);                                       // нажали кн Старт

function click_start() {                                                                            // ! нажатие кн Старт  
    execute_initial_actions_interface();                                                            // начальные действия с интерфейсом

    data.scan_option = get_scan_option(CONFIG.ELEMENTS.SCAN_OPTION);                                // * ШАГ 1 - получить вариант сканируемых страниц
    add_write_log(CONFIG.ELEMENTS.LOGS, `работаем с ${data.scan_option}`);                          // добавить запись в лог

    data.scan_links = get_scan_links(XML_DATA.PAGES, data.scan_option);                             // * ШАГ 2 - получить список ссылок, сканируемых страниц
    add_write_log(CONFIG.ELEMENTS.LOGS, `сканируемые ссылки: ${data.scan_links}`);                  // добавить запись в лог

    data.temp_folder_name = create_temporary_folder_name();                                         // * ШАГ 3 - создать имя временной папки
    add_write_log(CONFIG.ELEMENTS.LOGS, `временная папка: ${data.temp_folder_name}`);               // добавить запись в лог

    create_temp_folder(                                                                             // * ШАГ 4 - создать временную папку на сервере
        CONFIG.SETTINGS.PHP_FILE,                                                                   // файл обработчик на сервере
        CONFIG.SETTINGS.FOLDER_TEMPL_DIR,                                                           // папка для временных папок
        data.temp_folder_name);                                                                     // имя временной папки

    setTimeout(() => {
        if (data.temp_folder_status === 'established') {                                            // если временная папка создана
            add_write_log(CONFIG.ELEMENTS.LOGS, `временная папка создана`);                         // добавить запись в лог

            data.offers = creating_empty_offers(data.scan_links);                                   // * ШАГ 5 - создание пустых offer`ов
            add_write_log(CONFIG.ELEMENTS.LOGS, `созданно ${data.offers.length} офферов`);          // добавить запись в лог

            execute_filling_offers(                                                                 // * ШАГ 6 - заполнить офферы данными 
                CONFIG.SETTINGS.PHP_FILE,                                                           // файл обработчик на сервере (для создания файла-генератора)
                CONFIG.SETTINGS.FOLDER_TEMPL_DIR,                                                   // папка для временных папок (для создания файла-генератора)
                data.temp_folder_name                                                               // имя временной папки (для создания файла-генератора)
            );

            let timer_offer_completion_status = setInterval(() => {                                 // запустить отслеживание статуса заполнения всех офферов данными
                if (data.offer_completion_status) {                                                 // если положительный
                    add_write_log(CONFIG.ELEMENTS.LOGS, `Создание XML`);                            // добавить запись в лог
                    clearTimeout(timer_offer_completion_status);                                    // остановить отслеживание
                    create_xml(data.offers);                                                        // * ШАГ 7 - запустить создание XML
                }
            }, CONFIG.SETTINGS.OFFER_COMPLETION_STATUS_TIME);

            let timer_create_xml_status = setInterval(() => {                                       // запустить отслеживание статуса заполнения всех офферов данными
                if (data.xml_create_status) {                                                       // если положительный
                    add_write_log(CONFIG.ELEMENTS.LOGS, `Работа завершена`);                        // добавить запись в лог
                    clearTimeout(timer_create_xml_status);                                          // остановить отслеживание
                    execute_final_steps(CONFIG.SETTINGS.PHP_FILE, CONFIG.SETTINGS.FOLDER_TEMPL_DIR, data.temp_folder_name);     // * ШАГ 8 - запустить финальные действия
                }
            }, CONFIG.SETTINGS.OFFER_COMPLETION_STATUS_TIME);
        } else { add_write_log(CONFIG.ELEMENTS.LOGS, `временная папка НЕ создана`); }               // добавить запись в лог
    }, CONFIG.SETTINGS.CREATE_XML_STATUS_TIME);
}