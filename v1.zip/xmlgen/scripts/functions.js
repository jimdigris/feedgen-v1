'use strict';

function get_scan_option(inputs) {                                                                  // ! получить вариант сканируемых страниц
    let selected_value;                                                                             // выбранный вариант
    inputs.forEach((input) => {                                                                     // перебор всех input
        if (input.checked) { selected_value = input.value; }                                        // выбранный вариант = значению input
    });
    return selected_value;                                                                          // вернуть значение         
}

function add_write_log(element, text) {                                                             // ! добавить запись в лог
    let content = element.innerHTML;                                                                // получим текущее содержимое
    element.innerHTML = `${content} <p>${text}</p>`;                                                // добавим новую запись и отобразим
    element.scrollTo(0, element.scrollHeight);                                                      // прокрутка вниз
}

function clear_data(execute_file, temp_folder_name, name) {                                             // ! очистить рабочие данные
    (function () {                                                                                      // очистить времененную папку
        let xhr = new XMLHttpRequest();                                                                 // создаем экземпляр класса XMLHttpRequest 
        let request = `action=clear_temp_folder&parent=${temp_folder_name}&name=${name}`;               // формируем запрос

        xhr.onreadystatechange = () => {                                                                // когда запрос завершен и ответ готов
            if (xhr.readyState === 4) {                                                                 // если пришел ответ от сервера
                add_write_log(CONFIG.ELEMENTS.LOGS, xhr.response['status']);                            // добавить запись в лог
            }
        }

        xhr.open('POST', execute_file);                                                                 // указываем параметры соединения
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');                      // формируем заголовок
        xhr.responseType = 'json';                                                                      // получаем json
        xhr.send(request);                                                                              // отправляем запрос 
    }());

    data = {                                                                                        // задать параметры по умолчанию
        scan_option: '',                                                                            // выбор сканируемых страниц
        scan_links: [],                                                                             // список ссылок, сканируемых страниц
        temp_folder_name: '',                                                                       // имя временной папки
        temp_folder_status: '',                                                                     // статус временной папки
        xml_create_status: false,                                                                   // статус xml файла
        offers: [],                                                                                 // xml <offer></offer>
        iterate_over_elements: false,                                                               // результат создания файла-генератора (при наполнении данными)
        number_page_scans: 0,                                                                       // кол-во повторных сканирований сгенерированной страницы
        offer_completion_status: false,                                                             // статус заполнения всех офферов данными
    };
}

function get_scan_links(pages, option) {                                                            // ! получить список ссылок для сканирования
    switch (option) {
        case 'apparat': return pages.APPARAT;
        case 'camera': return pages.CAMERA;
        case 'komplekt': return pages.KOMPLEKT;
        case 'kompressor': return pages.KOMPRESSOR;
        case 'all':
            let all_pages = [];
            for (let key in pages) { all_pages.push(...pages[key]); }                               // объединим все массивы
            return all_pages;                                                                       // вернуть значение  
    }
}

function create_temporary_folder_name() { return Math.floor(Math.random() * 9999999); }             // ! создать имя временной папки

function create_temp_folder(execute_file, parent_folder, temp_folder_name) {                        // ! создать временную папку на сервере
    let xhr = new XMLHttpRequest();                                                                 // создаем экземпляр класса XMLHttpRequest 
    let request = `action=create_temp_folder&parent=${parent_folder}&name=${temp_folder_name}`;     // формируем запрос
    xhr.onreadystatechange = () => {                                                                // когда запрос завершен и ответ готов
        if (xhr.readyState === 4) { data.temp_folder_status = xhr.response['status']; }             // задать статус временной папке (созданна / не созданна)
    }
    xhr.open('POST', execute_file);                                                                 // указываем параметры соединения
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');                      // формируем заголовок
    xhr.responseType = 'json';                                                                      // получаем json
    xhr.send(request);                                                                              // отправляем запрос 
}

function creating_empty_offers(scan_links) {                                                        // ! создание пустых offer`ов
    let offers = [];                                                                                // пустые offer`ы
    let offer_id = 0;                                                                               // идентификатор оффера

    scan_links.forEach((link) => {                                                                  // перебрать ссылки для сканирования
        let offer = new Offer(offer_id, link);                                                      // создать offer
        offers.push(offer);                                                                         // добавить в массив
        offer_id++;
    });

    return offers;                                                                                  // вернуть значение 
}

function execute_filling_offers(execute_file, parent_folder, temp_folder_name) {                    // !! выполнить заполнение офферов данными
    let data_filling_offers = {                                                                     // данные для выполнения операций
        execute_file: execute_file,                                                                 // выполняемый php файл на сервере
        parent_folder: parent_folder,                                                               // имя родительской папки
        temp_folder_name: temp_folder_name,                                                         // имя временной папки
        index_offer: 0,                                                                             // номер, обрабатываемого оффера
        count_offers: data.offers.length,                                                           // кол-во обрабатываемых офферов
    };

    iterate_over_elements(data_filling_offers);                                                     // выполнить первый перебор элементов
}

function iterate_over_elements(data_filling_offers) {                                               // ! перебор офферов
    create_file_generator(data_filling_offers);                                                     // * ШАГ 6.1 - создать файл генератор

    let timer = setInterval(() => {                                                                 // проверяем результат получения данных для оффера
        if (data.iterate_over_elements) {                                                           // если удачно
            clearTimeout(timer);                                                                    // останавливаем таймер проверки
            data.iterate_over_elements = false;                                                     // сборосить значение параметра

            if (data_filling_offers.index_offer < data_filling_offers.count_offers - 1) {           // если не последний элемент
                data_filling_offers.index_offer++;
                iterate_over_elements(data_filling_offers);                                         // запускаем обработку сл элемента (оффера)
            } else {
                add_write_log(CONFIG.ELEMENTS.LOGS, `все офферы обработанны`);                      // добавить запись в лог
                console.log(data.offers);
                data.offer_completion_status = true;                                                // * изменить статус заполнения всех офферов - на положительный
            }
        }
    }, CONFIG.SETTINGS.ITERATE_OVER_ELEMENTS_TIME);
}

function create_file_generator(data_filling_offers) {                                               // ! для offer - создать файл генератор
    let xhr = new XMLHttpRequest();                                                                 // создаем экземпляр класса XMLHttpRequest 

    let offer_id = data.offers[data_filling_offers.index_offer].offer_id;                           // идентификатор оффера
    let link_page = data.offers[data_filling_offers.index_offer].link_page;                         // ссылка на сканируемую старницу

    let request = `action=create_file_generator&parent=${data_filling_offers.parent_folder}&name=${data_filling_offers.temp_folder_name}&id=${offer_id}&link=${link_page}`;   // формируем запрос

    xhr.onreadystatechange = () => {                                                                // когда запрос завершен и ответ готов
        if (xhr.readyState === 4) {                                                                 // если пришел ответ от сервера
            if (xhr.response['status'] === 'established') {                                         // если файл-генератор создался
                data.offers[data_filling_offers.index_offer].file_generator = xhr.response['file']; // записать путь к файлу генератору
                add_write_log(CONFIG.ELEMENTS.LOGS, `Страница № ${data_filling_offers.index_offer} <br> 1) генератор для ${link_page} - создан`);      // добавить запись в лог

                get_data_offer(data_filling_offers.index_offer);                                    // * ШАГ 6.2 - получить данные для офера
            } else {
                add_write_log(CONFIG.ELEMENTS.LOGS, `не удалось создать генератор для ${link_page}`);   // добавить запись в лог
            }
        }
    }

    xhr.open('POST', data_filling_offers.execute_file);                                             // указываем параметры соединения
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');                      // формируем заголовок
    xhr.responseType = 'json';                                                                      // получаем json
    xhr.send(request);                                                                              // отправляем запрос
}

function get_data_offer(i) {                                                                        // ! для offer - получить данные для оффера
    add_write_log(CONFIG.ELEMENTS.LOGS, `2) генерируем страницу: ${data.offers[i].link_page}`);     // добавить запись в лог

    get_data_iframe(CONFIG.SETTINGS.IFRAME_LOAD_TIME);                                              // получить данные из iframe

    function get_data_iframe(time) {                                                                // ! для offer - получить данные из iframe (время на прогрузку данных в iframe)
        CONFIG.ELEMENTS.IFRAME.src = data.offers[i].file_generator;                                 // добавить ссылку на файл-генератор в ifreame

        CONFIG.ELEMENTS.IFRAME.onload = function () {                                               // после прогрузки iframe
            setTimeout(() => {
                add_write_log(CONFIG.ELEMENTS.LOGS, `3) сканируем страницу: ${data.offers[i].link_page}`);      // добавить запись в лог

                let iframe_doc = CONFIG.ELEMENTS.IFRAME.contentWindow.document;                                 // получаем содержимое iframe

                try {
                    data.offers[i].xml_data.id = iframe_doc.querySelector(`.${CONFIG.CLASSES.ID}`).textContent;
                    data.offers[i].xml_data.url = iframe_doc.querySelector(`.${CONFIG.CLASSES.URL}`).textContent;
                    data.offers[i].xml_data.price = iframe_doc.querySelector(`.${CONFIG.CLASSES.PRICE}`).textContent;
                    data.offers[i].xml_data.category_id = iframe_doc.querySelector(`.${CONFIG.CLASSES.CATEGORY_ID}`).textContent;
                    data.offers[i].xml_data.model = iframe_doc.querySelector(`.${CONFIG.CLASSES.MODEL}`).textContent;
                    data.offers[i].xml_data.description_mini = iframe_doc.querySelector(`.${CONFIG.CLASSES.DESCRIPTION_MINI}`).textContent;
                    data.offers[i].xml_data.description_product = iframe_doc.querySelector(`.${CONFIG.CLASSES.DESCRIPTION_PRODUCT}`).textContent;
                    data.offers[i].xml_data.picture = get_url(iframe_doc.querySelector(`.${CONFIG.CLASSES.PICTURE}`).querySelectorAll('img'));
                    data.offers[i].xml_data.description_full = data.offers[i].xml_data.description_mini.replace(/[^\w\sА-Яа-яЁё\.\,\+\-\:\;\?\!\\\/]/gi, '') + data.offers[i].xml_data.description_product.replace(/[^\w\sА-Яа-яЁё\.\,\+\-\:\;\?\!\\\/]/gi, '');
                } catch (err) {                                                                                 // если iframe не успел полностью прогрузиться
                    if (data.number_page_scans < CONFIG.SETTINGS.MAX_NUMBER_PAGE_SCANS) {                       // если не привышен порог разрешенных повторов сканирования
                        data.number_page_scans++;                                                               // увеличить значение использованных попыток
                        add_write_log(CONFIG.ELEMENTS.LOGS, `!!! Ошибка загрузки страницы. Повторное сканирование №${data.number_page_scans}.`);     // добавить запись в лог
                        get_data_iframe(CONFIG.SETTINGS.MAX_IFRAME_LOAD_TIME);                                  // запустить повторное сканирование, с увеличенным временем ожидания
                        return;                                                                                 // прервать дальнейшее выполнение
                    } else {
                        data.number_page_scans = 0;                                                             // сбросить значение использованных попыток
                        add_write_log(CONFIG.ELEMENTS.LOGS, `!!! Превышены попытки сканирования. Переходим к сл. элементу`);                        // добавить запись в лог
                        data.iterate_over_elements = true;                                                      // разрешить переход к сл итерации
                        return;                                                                                 // прервать дальнейшее выполнение
                    }
                }

                let array = data.offers[i].xml_data;                                                                // полученные данные

                for (var key in array) {                                                                            // проверим все ли данные получены
                    if ((array[key] === null) || (array[key] === '')) {                                             // если не полученны или пусто
                        if (data.number_page_scans < CONFIG.SETTINGS.MAX_NUMBER_PAGE_SCANS) {                       // если не привышен порог разрешенных повторов сканирования
                            data.number_page_scans++;
                            add_write_log(CONFIG.ELEMENTS.LOGS, `!!! Ошибка считывания данных. Повторное сканирование №${data.number_page_scans}.`);    // добавить запись в лог
                            get_data_iframe(CONFIG.SETTINGS.MAX_IFRAME_LOAD_TIME);                                  // запустить повторное сканирование, с увеличенным временем ожидания
                            return;                                                                                 // прервать дальнейшее выполнение
                        } else {
                            data.number_page_scans = 0;                                                             // сбросить значение использованных попыток
                            add_write_log(CONFIG.ELEMENTS.LOGS, `!!! Превышены попытки сканирования. Переходим к сл. элементу`);                        // добавить запись в лог
                            return;                                                                                 // прервать дальнейшее выполнение
                        }
                    }
                }

                // если все данные полученны            
                add_write_log(CONFIG.ELEMENTS.LOGS, `4) данные для ${data.offers[i].link_page} полученны`);         // добавить запись в лог
                data.number_page_scans = 0;                                                                         // сбросить значение использованных попыток
                data.iterate_over_elements = true;                                                                  // разрешить переход к сл итерации
            }, time);
        }
    }

    function get_url(elements) {                                                                    // ! для offer - получим массив ссылок на изображения из элементов
        let images = Array.from(elements);
        let url = images.map((image) => { return image.src; });
        return url;                                                                                 // и вернем их обратно
    }
}


function create_xml(offers) {                                                                       // ! запустить создание XML
    let date = new Date();                                                                          // получить текущую дату

    let xml = {                                                                                     // данные для сормирования xml
        date: date.toISOString().split('.')[0],                                                     // * ШАГ 7.1 - дата
        category: '',                                                                               // категории
        offer: '',                                                                                  // товары
        content: '',                                                                                // полное содержимое файла
    }

    XML_DATA.CATIGORY.forEach((item) => {                                                                       // * ШАГ 7.2 - генерация содержимого блока с категориями
        if (item[1] == '') { xml.category += `<category id="${item[0]}">${item[2]}</category>\n`; }             // для корневого раздела
        else { xml.category += `<category id="${item[0]}" parentId="${item[1]}">${item[2]}</category>\n`; }     // для дочерних разделов
    });

    outer: for (let offer of offers) {
        let pictures = '';                                                                                      // изображения
        let random_id = get_random_arbitrary(0, 999);                                                           // случайное число для подстановки в id товара
        let price = '';                                                                                         // цена

        for (let key in offer.xml_data) {                                                                           // переберем свойства xml оффера
            // если не заполненно или не подходит под условие
            if ((offer.xml_data[key] === null) || (offer.xml_data[key] === '' || (offer.xml_data[key] === '1.0') || (offer.xml_data[key] === 'Предзаказ'))) {
                add_write_log(CONFIG.ELEMENTS.LOGS, `!!! Товар ${offer.link_page} не добавлен. (нет: ${key})`);     // добавить запись в лог
                continue outer;                                                                                     // прейти к сл офферу
            }
        }

        offer.xml_data.picture.forEach((pic) => { pictures += `<picture>${pic}</picture>\n`; });                // * ШАГ 7.3 - генерация списка изображений для товара

        price = offer.xml_data.price.replace(/[^0-9\.]/g, "");                                                  // * ШАГ 7.4 - цена - убираем лишние символы, оставляем только цифры и точку


        // * ШАГ 7.5 - генерация xml офферов
        xml.offer += `<offer type="vendor.model" available="true" id="${offer.xml_data.id}${random_id}" >       
        <url>${offer.xml_data.url}</url>
        <price>${price}</price>
        <currencyId>RUB</currencyId>
        <categoryId>${offer.xml_data.category_id}</categoryId> 
        ${pictures}                      
        <store>false</store>
        <pickup>true</pickup>
        <delivery>true</delivery>
        <vendor>PST</vendor>
        <model>${offer.xml_data.model}</model>
        <description>${offer.xml_data.description_full}</description> 
        </offer>\n`;
    }

    // * ШАГ 7.6 - генерация полного содержимого файла
    xml.content = `<?xml version="1.0" encoding="utf-8"?>                                                       
    <!DOCTYPE yml_catalog SYSTEM "shops.dtd">
    <yml_catalog date="${xml.date}">
    <shop>
            <name>${XML_DATA.INFO.NAME}</name>
            <company>${XML_DATA.INFO.COMPANY}</company>
            <url>${XML_DATA.INFO.LINK_SITE}</url>
            <platform>${XML_DATA.INFO.PLATFORM}</platform>
            <currencies>            
                <currency id="RUB" rate="1.0"  />            
            </currencies>
            <categories>
                ${xml.category}
            </categories>        
            <offers>
                ${xml.offer} 
            </offers>
            <promos> </promos>
        </shop>
    </yml_catalog>                         
    `;

    // * ШАГ 7.7 - создание файла на сервере
    let xhr = new XMLHttpRequest();                                                                 // создаем экземпляр класса XMLHttpRequest

    let request = `action=create_xml_file&parent=${CONFIG.SETTINGS.FOLDER_TEMPL_DIR}&name=${data.temp_folder_name}&content=${xml.content}`;     // формируем запрос

    xhr.onreadystatechange = () => {                                                                // когда запрос завершен и ответ готов
        if (xhr.readyState === 4) {                                                                 // если пришел ответ от сервера
            if (xhr.response['status'] === 'established') {                                         // если файл-генератор создался
                add_write_log(CONFIG.ELEMENTS.LOGS, `XML файл создан!`);                            // добавить запись в лог
                data.link_xml_file = xhr.response['file'];                                          // получить ссылку на xml файл
                data.xml_create_status = true;                                                      // задать что файл xml создан
            }
        }
    }

    xhr.open('POST', CONFIG.SETTINGS.PHP_FILE);                                                     // указываем параметры соединения
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');                      // формируем заголовок
    xhr.responseType = 'json';                                                                      // получаем json
    xhr.send(request);                                                                              // отправляем содержимое файла    
};

function get_random_arbitrary(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

function execute_final_steps(execute_file, temp_folder_name, name) {                                // ! запустить финальные действия
    execute_final_actions_interface();                                                              // финальные действия с интерфейсом
    clear_data(execute_file, temp_folder_name, name);                                               // очистить рабочие данные (для повторного нажатия)
}

function execute_initial_actions_interface() {                                                      // ! начальные действия с интерфейсом
    CONFIG.ELEMENTS.START.disabled = true;                                                          // сделать не активной кн Старт
    CONFIG.ELEMENTS.DOWNLOAD.style = 'none';                                                        // скрыть кн Скачать
}

function execute_final_actions_interface() {                                                        // ! финальные действия с интерфейсом
    CONFIG.ELEMENTS.START.disabled = false;                                                         // сделать активной кн Старт
    CONFIG.ELEMENTS.DOWNLOAD.href = data.link_xml_file;                                             // добавить ссылку на xml файл
    CONFIG.ELEMENTS.DOWNLOAD.style.display = 'block';                                               // показать кн Скачать
}

