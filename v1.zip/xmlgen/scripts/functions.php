<?php

function create_temp_folder($parent, $name)                                                         // ! создать временную папку
{
    $dir = "$parent/$name";                                                                         // формируем путь до папки

    mkdir($dir, 0755);                                                                              // создаем папку

    if (file_exists($dir)) {                                                                        // проверить создалась ли папка
        $response = ['status' => 'established'];
        echo json_encode($response, true);                                                          // отправить ответ
    } else {
        $response = ['status' => 'no_established'];
        echo json_encode($response, true);                                                          // отправить ответ
    }
}

function create_file_generator($parent, $name, $id, $link)                                          // ! создать файл генератор, сканируемой страницы
{
    $body = "<?php \$html = file_get_contents('$link', true); echo \$html;";                        // содержимое генератора

    $file = "$parent/$name/$id.php";                                                                // создаем полный путь с именем файла
    file_put_contents($file, $body);                                                                // создаем файл-генератор

    if (file_exists($file)) {                                                                       // проверить создался ли файл
        $response = ['status' => 'established', 'file' => "$file"];
        echo json_encode($response, true);                                                          // отправить ответ
    } else {
        $response = ['status' => 'no_established'];
        echo json_encode($response, true);                                                          // отправить ответ
    }
}

function create_xml_file($parent, $name, $content)                                                  // ! создать XML файл
{
    $file = "$parent/fids/fid-$name.xml";                                                           // создаем полный путь с именем файла
    file_put_contents($file, $content);                                                             // создаем

    if (file_exists($file)) {                                                                       // проверить создался ли файл
        $response = ['status' => 'established', 'file' => $file];                                   // вернуть путь к xml файлу
        echo json_encode($response, true);                                                          // отправить ответ
    } else {
        $response = ['status' => 'no_established'];
        echo json_encode($response, true);                                                          // отправить ответ
    }
}

function clear_temp_folder($dir)                                                                    // ! удалить временную папку 
{
    $response = ['status' => 'Временные файлы удалены'];
    echo json_encode($response, true);                                                              // отправить ответ

    if ($objs = glob($dir . '*')) {
        foreach ($objs as $obj) {
            is_dir($obj) ? clear_temp_folder($obj) : unlink($obj);
        }
    }
    rmdir($dir);
}
